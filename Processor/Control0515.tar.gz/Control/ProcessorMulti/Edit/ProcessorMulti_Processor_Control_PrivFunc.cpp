//You need to program this file.

#include "../NoEdit/ProcessorMulti_Processor_Control_PrivFunc.h"
#include "../control.h"
#include <iostream>
//*******************Please add static libraries in .pro file*******************
//e.g. unix:LIBS += ... or win32:LIBS += ...

bool DECOFUNC(setParamsVarsOpenNode)(QString qstrConfigName, QString qstrNodeType, QString qstrNodeClass, QString qstrNodeName, void * paramsPtr, void * varsPtr)
{
	XMLDomInterface xmlloader(qstrConfigName,qstrNodeType,qstrNodeClass,qstrNodeName);
	ProcessorMulti_Processor_Control_Params * params=(ProcessorMulti_Processor_Control_Params *)paramsPtr;
	ProcessorMulti_Processor_Control_Vars * vars=(ProcessorMulti_Processor_Control_Vars *)varsPtr;
	/*======Please Program below======*/
	/*
	Function: open node.
	Procedure:
	1: load parameters (params). [GetParamValue(xmlloader,params,tag); GetEnumParamValue(xmlloader,params,tag); GetUEnumParamValue(xmlloader,params,tag)]
	2: initialize variables (vars).
	3: If everything is OK, return 1 for successful opening and vice versa.
	*/
    GetParamValue(xmlloader, vars, WheelBase);
    GetParamValue(xmlloader, vars, WheelRadius);
    GetParamValue(xmlloader, vars, max_linearVel);
    GetParamValue(xmlloader, vars, targetPt_index);

    vars->last_traj.clear();
    vars->last_trajindex = 0;
	return 1;
}

bool DECOFUNC(handleVarsCloseNode)(void * paramsPtr, void * varsPtr)
{
	ProcessorMulti_Processor_Control_Params * params=(ProcessorMulti_Processor_Control_Params *)paramsPtr;
	ProcessorMulti_Processor_Control_Vars * vars=(ProcessorMulti_Processor_Control_Vars *)varsPtr;
	/*======Please Program below======*/
	/*
	Function: close node.
	Procedure:
	1: handle/close variables (vars).
	2: If everything is OK, return 1 for successful closing and vice versa.
	*/
	
	return 1;
}

void DECOFUNC(getInternalTrigger)(void * paramsPtr, void * varsPtr, QObject * & internalTrigger, QString & internalTriggerSignal)
{
	ProcessorMulti_Processor_Control_Params * params=(ProcessorMulti_Processor_Control_Params *)paramsPtr;
	ProcessorMulti_Processor_Control_Vars * vars=(ProcessorMulti_Processor_Control_Vars *)varsPtr;
	internalTrigger=NULL;
	internalTriggerSignal=QString();
	/*======Occasionally Program above======*/
	/*
	Function: get internal trigger [defined in vars] for node.
	You need to program here when you need internal trigger (internalTrigger + internalTriggerSignal) for node.
	E.g.
	internalTrigger=&(vars->trigger);
	internalTriggerSignal=QString(SIGNAL(triggerSignal()));
	*/
}

void DECOFUNC(initializeOutputData)(void * paramsPtr, void * varsPtr, boost::shared_ptr<void> & outputDataPtr)
{
	ProcessorMulti_Processor_Control_Params * params=(ProcessorMulti_Processor_Control_Params *)paramsPtr;
	ProcessorMulti_Processor_Control_Vars * vars=(ProcessorMulti_Processor_Control_Vars *)varsPtr;
	outputDataPtr=boost::shared_ptr<void>(new ProcessorMulti_Processor_Control_Data());
	/*======Occasionally Program below/above======*/
	/*
	Function: initial output data.
	You need to program here when you need to manually initialize output data.
	*/
	
}

void DECOFUNC(getMultiInputDataSize)(void * paramsPtr, void * varsPtr, QList<int> & inputDataSize)
{
	ProcessorMulti_Processor_Control_Params * params=(ProcessorMulti_Processor_Control_Params *)paramsPtr;
	ProcessorMulti_Processor_Control_Vars * vars=(ProcessorMulti_Processor_Control_Vars *)varsPtr;
	inputDataSize=QList<int>();
	/*======Please Program above======*/
	/*
	Function: get input data size to be grabbed from buffer.
	Rules:
	inputDataSize=0: grab and remove all data from buffer.
	inputDataSize>0: grab inputDataSize latest data from buffer.
	inputDataSize<0: grab and remove inputDataSize ancient data from buffer.
	E.g.
	inputDataSize=QList<int>()<<0<<1<<-1...;
	*/
}

//Input Port #0: Buffer_Size = 10, Params_Type = ProcessorMono_Processor_PathGenerator_Params, Data_Type = ProcessorMono_Processor_PathGenerator_Data
//Input Port #1: Buffer_Size = 10, Params_Type = SensorInternalEvent_Sensor_Joystick_Params, Data_Type = SensorInternalEvent_Sensor_Joystick_Data
bool DECOFUNC(processMultiInputData)(void * paramsPtr, void * varsPtr, QVector<QVector<void *> > inputParams, QVector<QVector<void *> > inputData, void * outputData, QList<int> & outputPortIndex)
{
	ProcessorMulti_Processor_Control_Params * params=(ProcessorMulti_Processor_Control_Params *)paramsPtr;
	ProcessorMulti_Processor_Control_Vars * vars=(ProcessorMulti_Processor_Control_Vars *)varsPtr;
	QVector<ProcessorMono_Processor_PathGenerator_Params *> inputparams_0; copyQVector(inputparams_0,inputParams[0]);
	QVector<SensorInternalEvent_Sensor_Joystick_Params *> inputparams_1; copyQVector(inputparams_1,inputParams[1]);
	QVector<ProcessorMono_Processor_PathGenerator_Data *> inputdata_0; copyQVector(inputdata_0,inputData[0]);
	QVector<SensorInternalEvent_Sensor_Joystick_Data *> inputdata_1; copyQVector(inputdata_1,inputData[1]);
	ProcessorMulti_Processor_Control_Data * outputdata=(ProcessorMulti_Processor_Control_Data *)outputData;
	outputPortIndex=QList<int>();
	if(inputdata_0.size()==0){return 0;}
	if(inputdata_1.size()==0){return 0;}
	/*======Please Program below======*/
	/*
	Step 1: process inputdata_index, then store it into outputdata.
	Step 2 [optional]: determine the outputPortIndex. (if not, outputdata will be sent by all ports)
	E.g. outputPortIndex=QList<int>()<<(outportindex1)<<(outportindex2)...
	*/
    SensorInternalEvent_Sensor_Joystick_Data* joystickdata = inputdata_1.front();
    ProcessorMono_Processor_PathGenerator_Data* pathdata = inputdata_0.front();

    short left_motor;
    short right_motor;

    int trajsize = 0;//判断是否有轨迹
    for(int i=0; i<pathdata->trajSets.size(); i++)
    {
        trajsize += pathdata->trajSets[i].size();
    }
    if(trajsize != 0)
    {
        int trajec_index = (pathdata->trajSets.size())/2;
        int i,k;
        //左右枚举targetPt_index
        for(i=0; i<=trajec_index; i++ )
        {
            k = trajec_index -i;
            if(pathdata->trajSets[k].size() > 0)
            {
                trajec_index = k;
                break;
            }
            k = trajec_index +i;
            if(pathdata->trajSets[k].size() > 0)
            {
                trajec_index = k;
                break;
            }
        }

        vars->last_traj = pathdata->trajSets;
        vars->last_trajindex = trajec_index;

    }

    double hx = cos(pathdata->startPoint.theta + PI/2);
    double hy = sin(pathdata->startPoint.theta + PI/2);
    double tx = pathdata->startPoint.x,ty=pathdata->startPoint.y;
    if(vars->targetPt_index < pathdata->trajSets[vars->last_trajindex].size())
    {
        tx = vars->last_traj[vars->last_trajindex].at(vars->targetPt_index).x;
        ty = vars->last_traj[vars->last_trajindex].at(vars->targetPt_index).y;
    }
    else
    {
        std::cout<<"targetPt_index out of range"<<std::endl;
    }



    if(joystickdata->manual_control == 1)
    {
        vars->left_vel = joystickdata->linear_vel + vars->WheelBase*joystickdata->angular_vel/2;
        vars->right_vel = joystickdata->linear_vel - vars->WheelBase*joystickdata->angular_vel/2;
    }
    else
    {
        generateControlCmd(vars, pathdata->startPoint.x, pathdata->startPoint.y, hx, hy, tx, ty);
    }



//    left_motor = vars->left_vel * 1000;
//    right_motor = vars->right_vel * 1000;

    ///zhan kong bi
    //left_motor = vars->left_vel * 1376.9 + 214.5;
    //right_motor = vars->right_vel * 1376.9 + 214.5;
    left_motor = vars->left_vel;
    right_motor = vars->right_vel;

    outputdata->left_vel = vars->left_vel;
    outputdata->right_vel = vars->right_vel;

    outputdata->isManualControl = joystickdata->manual_control;

    outputdata->startpoint = pathdata->startPoint;

    outputdata->targetPt_index = vars->targetPt_index;

    outputdata->target_trajec.clear();
    outputdata->target_trajec = vars->last_traj[vars->last_trajindex];

    outputdata->trajSets.clear();
    outputdata->trajSets = vars->last_traj;

    outputdata->targetPt_index = outputdata->targetPt_index<0 ? 0:outputdata->targetPt_index;
    outputdata->targetPt_index = outputdata->targetPt_index> (vars->last_traj[vars->last_trajindex].size()-1) \
            ? (vars->last_traj[vars->last_trajindex].size()-1) : outputdata->targetPt_index;

    outputdata->left_motor = left_motor;
    outputdata->right_motor = right_motor;

	return 1;
}

