#ifndef CONTROLVIS
#define CONTROLVIS
#include "../NoEdit/VisualizationMono_Processor_Control_PrivFunc.h"

void drawWheelchair(const trajec_state& currentPos);
#endif // CONTROLVIS

